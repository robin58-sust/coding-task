<?php

	define('DB_HOST', '127.0.0.1');
	define('DB_USER','admin');
	define('DB_PASS', 'yourpass');
	define('DB_NAME', 'gogirlz');

?>