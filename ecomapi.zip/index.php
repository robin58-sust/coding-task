<!DOCTYPE html>
<html>
<title>Nikitas Studio Admin</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<style>
img {
    display: block;
    margin-left: auto;
    margin-right: auto;
}

body,
h2 {
    font-family: "Raleway", sans-serif;
    color: indigo;
    text-align: center;
}

body,
b {
    font-family: "Raleway", sans-serif;
    color: indigo;
    ;
}

body,
h6 {
    color: dimgrey;
    text-align: center
}

body,
html {
    height: 100%
}

.bgimg {
    background-image: url('bgimage.jpg');
    min-height: 100%;
    background-position: center;
    background-size: cover;
}
</style>

<body>

    <div class="bgimg w3-display-container w3-animate-opacity w3-text-white">
        <div class="w3-display-middle">
            <h2>Nikitas Studio</h2>

            <h4 style="color:white; text-align: center; width: 100%;"><b>Nikita's Studio new web admin</b> </h4>


        </div>
    </div>

</body>

</html>